#ifndef MODULESSOLOKHA_H_INCLUDED
#define MODULESSOLOKHA_H_INCLUDED

void info();
int abzac();
int check_word();
void dot_text();
float s_calculation(float x, float y, float z);

#endif // MODULESSOLOKHA_H_INCLUDED
